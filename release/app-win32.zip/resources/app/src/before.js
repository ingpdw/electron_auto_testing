'use strict';

module.exports = {
    before: function (browser) {

    },
    after: function (browser) {
        browser.end();
    }
}
